from controller import Robot
from datetime import datetime
import math
import numpy as np


class Controller:
    def __init__(self, robot):
        # Robot Parameters
        self.robot = robot
        self.time_step = 32  # ms
        self.max_speed = 1  # m/s

        # Enable Motors
        self.left_motor = self.robot.getDevice('left wheel motor')
        self.right_motor = self.robot.getDevice('right wheel motor')
        self.left_motor.setPosition(float('inf'))
        self.right_motor.setPosition(float('inf'))
        self.left_motor.setVelocity(0.0)
        self.right_motor.setVelocity(0.0)
        self.velocity_left = 0
        self.velocity_right = 0

        # Enable Proximity Sensors
        self.proximity_sensors = []
        for i in range(8):
            sensor_name = 'ps' + str(i)
            self.proximity_sensors.append(self.robot.getDevice(sensor_name))
            self.proximity_sensors[i].enable(self.time_step)

        # Enable Light Sensors
        self.light_sensors = []
        for i in range(8):
            sensor_name = 'ls' + str(i)
            self.light_sensors.append(self.robot.getDevice(sensor_name))
            # Set time step of time sensor to 11000, which is 11 secounds following a different layer
            # approach to delay the robots response to the light sensor
            self.light_sensors[i].enable(11000)

        # Data
        self.distance_inputs = []
        self.light_inputs = []
        self.light_inputs_previous = []

    def clip_value(self, value, min_max):
        if (value > min_max):
            return min_max
        elif (value < -min_max):
            return -min_max
        return value

    def sense_compute_and_actuate(self):
        if len(self.distance_inputs) > 0:
            # calculate the difference between the left and right distance sensors
            right_distance = round(np.max(self.distance_inputs[0:3]), -1)
            left_distance = round(np.max(self.distance_inputs[3:6]), -1)
            distance_diff = np.abs(left_distance - right_distance)
            velocity_difference = min((distance_diff / 2400) * 0.5, 0.5)
            # if the left distance sensors are greater than the right distance sensors, go left
            if (right_distance > left_distance and (self.distance_inputs[0] < 90 or self.distance_inputs[5] < 90)):
                self.velocity_left = 1 - velocity_difference
                self.velocity_right = 1 + velocity_difference
            elif (right_distance < left_distance and (self.distance_inputs[0] < 90 or self.distance_inputs[5] < 90)):
                self.velocity_left = 1 + velocity_difference
                self.velocity_right = 1 - velocity_difference
            elif (right_distance == left_distance):
                self.velocity_left = 1
                self.velocity_right = 1
            # based on the previous two light values, if there has been a major change in the light go right else go left
            if ((self.distance_inputs[0] > 80 or self.distance_inputs[5] > 80) and abs(np.average(self.light_inputs) - np.average(self.light_inputs_previous)) > 0.2 and np.max(self.distance_inputs[1:3]) < 170):
                self.velocity_left = 1
                self.velocity_right = -1
            elif ((self.distance_inputs[0] > 80 or self.distance_inputs[5] > 80) and np.max(self.distance_inputs[3:5]) < 170):
                self.velocity_left = -1
                self.velocity_right = 1
        # Set Motor Velocities
        self.left_motor.setVelocity(self.velocity_left)
        self.right_motor.setVelocity(self.velocity_right)

    def run_robot(self):
        # Main Loop
        count = 0
        inputs_avg = []

        while self.robot.step(self.time_step) != -1:

            # Read Distance Sensors
            temp_distance_inputs = []
            for i in range(8):
                if (i == 0 or i == 1 or i == 2 or i == 5 or i == 6 or i == 7):
                    temp = self.proximity_sensors[i].getValue()
                    # Adjust Values
                    min_ds = 0
                    max_ds = 2400
                    if (temp > max_ds):
                        temp = max_ds
                    if (temp < min_ds):
                        temp = min_ds
                    # Save Data
                    # temp_distance_inputs.append((temp-min_ds)/(max_ds-min_ds))
                    temp = round(temp, -1)
                    # print(temp)
                    temp_distance_inputs.append(temp)
            self.distance_inputs = temp_distance_inputs
            # print("Distance Sensors - Index: {}  Value: {}".format(i, self.proximity_sensors[i].getValue()))
            temp_light_inputs = []
            # Read Light Sensors
            for i in range(8):
                temp = self.light_sensors[i].getValue()
                # Adjust Values
                min_ls = 0
                max_ls = 4300
                if (temp > max_ls):
                    temp = max_ls
                if (temp < min_ls):
                    temp = min_ls
                # Save Data
                temp_light_inputs.append((temp-min_ls)/(max_ls-min_ls))
                # print("Light Sensors - Index: {}  Value: {}".format(i,self.light_sensors[i].getValue()))
            if (temp_light_inputs != self.light_inputs):
                self.light_inputs_previous = self.light_inputs
                self.light_inputs = temp_light_inputs
                print(self.light_inputs)
            # Compute and Actuate
            self.sense_compute_and_actuate()


if __name__ == "__main__":

    my_robot = Robot()
    controller = Controller(my_robot)
    controller.run_robot()
