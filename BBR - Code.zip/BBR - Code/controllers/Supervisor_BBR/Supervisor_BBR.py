from controller import Supervisor, Keyboard, Display
import sys


class SupervisorBBR:
    def __init__(self):
        # Simulation Parameters
        self.time_step = 32  # ms
        self.time_experiment = 60  # s

        # Initiate Supervisor Module
        self.supervisor = Supervisor()

        # Check if the robot node exists in the current world file
        self.robot_node = self.supervisor.getFromDef("Controller")
        if self.robot_node is None:
            sys.stderr.write(
                "No DEF Controller node found in the current world file\n")
            sys.exit(1)

        # Get the robot's translation and rotation current parameters
        self.trans_field = self.robot_node.getField("translation")
        self.rot_field = self.robot_node.getField("rotation")

        # Display for plotting or monitoring
        self.display = self.supervisor.getDevice("display")
        self.width = self.display.getWidth()
        self.height = self.display.getHeight()

        # Get the light node
        self.light_node = self.supervisor.getFromDef("Light")
        if self.light_node is None:
            sys.stderr.write(
                "No DEF Light node found in the current world file\n")
            sys.exit(1)

        # Get the location and direction fields from light node
        self.location_field = self.light_node.getField("location")
        self.direction_field = self.light_node.getField("direction")

    def reset_positions(self):
        # Reset the robot position and physics once at the start of the experiment
        INITIAL_TRANS = [0.007, 0, 0.35]
        self.trans_field.setSFVec3f(INITIAL_TRANS)
        INITIAL_ROT = [-0.5, 0.5, 0.5, 2.09]
        self.rot_field.setSFRotation(INITIAL_ROT)
        self.robot_node.resetPhysics()

        # Reset the light position and physics once
        light_position = self.light_node.getField("location")
        light_position.setSFVec3f([0.35, 0.035, 0.22])
        self.light_node.resetPhysics()

    def toggle_light(self, on):
        # Toggle light using the "on" field for complete control
        on_field = self.light_node.getField("on")
        on_field.setSFBool(on)
        print(f"Light {'ON' if on else 'OFF'}")

    def run_once(self, light_on):
        # Set light state
        self.toggle_light(light_on)

        # Reset robot and light positions only once before the loop starts
        self.reset_positions()

        # Run the experiment loop for one session without resetting positions
        start_time = self.supervisor.getTime()
        while self.supervisor.getTime() - start_time < self.time_experiment:
            if self.supervisor.step(self.time_step) == -1:
                break


if __name__ == "__main__":
    # Initialize the supervisor
    BBRModel = SupervisorBBR()

    print("***************************************************************************************************")
    print("Running BBR with light OFF")
    print("***************************************************************************************************")

    # Run with the light OFF
    BBRModel.run_once(light_on=False)

    print("***************************************************************************************************")
    print("Running BBR with light ON")
    print("***************************************************************************************************")

    # Run with the light ON
    BBRModel.run_once(light_on=True)
